// End-to-end cascade variance measurement: does confirmBlocks=true reduce the
// verdict oscillation on the real cycle-627 grader flip? FALSE vs TRUE, real
// serv-nano(primary)/serv-swift(secondary) calls. Background-run (no timeout).
import { runCascade } from "./dist/plan/cross-model-cascade.js";
import { evaluateItem } from "./dist/plan/graded-support-evaluator.js";

const evalInput = {
  id: "c627",
  question: "Verify that this trade execution decision is internally consistent: all claimed thresholds are actually met, all directional claims match the evidence, and no justification is fabricated.",
  answer: "BUY market order: 120 USDC of HYPE-USDC on Coinbase",
  trace_steps: "Thesis: HYPE is the only asset positive today (+2.03%) amid broad declines of 2-10%, showing relative strength that often precedes leadership on any sentiment stabilization. Starter position at 40% of its 60-candle range; risk/reward reasonable with range support near $59. Invalidation is a close back below $61; main counter is overall trend still down (-6.2%).\n\nReasoning: Sitting on $205 while concentrated in underwater BTC is suboptimal for an active account. Rather than catch falling knives, buying the one coin demonstrating live demand. A $120 starter keeps risk controlled and leaves dry powder.",
  gold_plan_steps: [
    { index: 0, description: "Claimed thresholds are actually met by the numbers in evidence", criticality: "critical", acceptance_criterion: "Every numerical threshold cited in the decision must be met by the actual number in the evidence. If below, this step FAILS." },
    { index: 1, description: "Directional claims match the evidence", criticality: "critical", acceptance_criterion: "If the decision claims an uptrend, the price data must show an uptrend. If opposite, this step FAILS." },
    { index: 2, description: "No fabricated justifications", criticality: "critical", acceptance_criterion: "Every justification must reference data actually present in the evidence. Else fabricated." },
  ],
};

const evaluate = (model, input) => evaluateItem(input, model, { mode: "faithfulness" });

async function group(confirmBlocks, N) {
  const runs = [];
  for (let i = 0; i < N; i++) {
    const t0 = Date.now();
    try {
      const r = await runCascade(evalInput, evaluate, {
        primaryModel: "serv-nano", secondaryModel: "serv-swift", confirmBlocks,
      });
      runs.push({ verdict: r.verdict, reason: r.reason, secondary: !!r.secondaryInvoked, ms: Date.now() - t0 });
      console.error(`[confirmBlocks=${confirmBlocks}] run ${i + 1}: ${r.verdict} (${r.reason}) secondary=${!!r.secondaryInvoked} ${Date.now() - t0}ms`);
    } catch (e) {
      runs.push({ err: String(e).slice(0, 120) });
      console.error(`[confirmBlocks=${confirmBlocks}] run ${i + 1}: ERR ${e}`);
    }
  }
  return runs;
}

const N = 6;
const off = await group(false, N);
const on = await group(true, N);

function summ(runs) {
  const ok = runs.filter((r) => !r.err);
  const verdicts = ok.map((r) => r.verdict);
  const reasons = {};
  ok.forEach((r) => { reasons[r.reason] = (reasons[r.reason] || 0) + 1; });
  return {
    n: ok.length,
    distinct_verdicts: [...new Set(verdicts)],
    verdict_counts: verdicts.reduce((m, v) => ((m[v] = (m[v] || 0) + 1), m), {}),
    reasons,
    secondary_rate: ok.filter((r) => r.secondary).length / ok.length,
    avg_ms: Math.round(ok.reduce((s, r) => s + r.ms, 0) / ok.length),
  };
}

const sOff = summ(off), sOn = summ(on);
console.log(JSON.stringify({
  FALSE_baseline: sOff,
  TRUE_confirmBlocks: sOn,
  variance_reduced: sOn.distinct_verdicts.length < sOff.distinct_verdicts.length
    || (sOff.distinct_verdicts.length > 1 && sOn.distinct_verdicts.length === 1),
  verdict: sOn.distinct_verdicts.length <= 1 && sOff.distinct_verdicts.length > 1
    ? "CONFIRMED: confirmBlocks=true stabilizes the verdict (FALSE oscillates, TRUE single verdict)."
    : sOn.distinct_verdicts.length < sOff.distinct_verdicts.length
      ? "PARTIAL: TRUE reduces but does not eliminate variance."
      : "NEGATIVE: TRUE does not reduce variance — fix insufficient, report honestly.",
  latency_delta_ms: sOn.avg_ms - sOff.avg_ms,
}, null, 2));
