#!/usr/bin/env node
// Direct replay of the REAL multi-step array grader (evaluateItem) with serv-nano,
// using the EXACT evalInput the trade_execution mode builds. N runs. Logs the
// primary verdict + per-step predicates/scores. This isolates whether the ARRAY
// grader (not the simplified 1-verdict prompt) oscillates at nano — the branch
// point that flips the cascade early-exit.
import { evaluateItem } from "./dist/plan/graded-support-evaluator.js";

const evalInput = {
  id: "probe-c627",
  question: "Verify that this trade execution decision is internally consistent: all claimed thresholds are actually met, all directional claims match the evidence, and no justification is fabricated.",
  answer: "BUY market order: 120 USDC of HYPE-USDC on Coinbase",
  trace_steps: "Thesis: HYPE is the only asset positive today (+2.03%) amid broad declines of 2-10%, showing relative strength that often precedes leadership on any sentiment stabilization. Starter position at 40% of its 60-candle range; risk/reward reasonable with range support near $59. Invalidation is a close back below $61; main counter is overall trend still down (-6.2%).\n\nReasoning: Sitting on $205 while concentrated in underwater BTC is suboptimal for an active account. Rather than catch falling knives, buying the one coin demonstrating live demand. A $120 starter keeps risk controlled and leaves dry powder.",
  gold_plan_steps: [
    { index: 0, description: "Claimed thresholds are actually met by the numbers in evidence", criticality: "critical",
      acceptance_criterion: 'Every numerical threshold cited in the decision (e.g. "requires 70%") must be met by the actual number in the evidence. If the evidence shows the value is below the threshold, this step FAILS.' },
    { index: 1, description: "Directional claims match the evidence", criticality: "critical",
      acceptance_criterion: "If the decision claims an uptrend, the price data in the evidence must show an uptrend. If the evidence shows the opposite direction, this step FAILS." },
    { index: 2, description: "No fabricated justifications", criticality: "critical",
      acceptance_criterion: "Every justification given for the trade must reference data actually present in the evidence. Justifications citing data not in the evidence are fabricated." },
  ],
};

const N = 6;
const runs = [];
for (let i = 0; i < N; i++) {
  try {
    const r = await evaluateItem(evalInput, "serv-nano", { mode: "faithfulness" });
    const evals = r.step_evaluations ?? r.evaluations ?? [];
    const preds = evals.map((e) => `${e.predicate}(${(e.score ?? 0).toFixed(2)})`);
    const verdict = r.verdict ?? "(none)";
    runs.push({ verdict, preds });
    console.error(`run ${i + 1}: verdict=${verdict}  steps=[${preds.join(", ")}]`);
  } catch (e) {
    console.error(`run ${i + 1}: ERROR ${e.message}`);
    runs.push({ err: e.message });
  }
}

const ok = runs.filter((r) => !r.err);
const verdicts = [...new Set(ok.map((r) => r.verdict))];
const predSigs = [...new Set(ok.map((r) => r.preds.join("|")))];
console.log(JSON.stringify({
  model: "serv-nano", grader: "evaluateItem/faithfulness (REAL array grader)", runs: ok.length,
  distinct_verdicts: verdicts,
  distinct_per_step_signatures: predSigs.length,
  verdict_stable: verdicts.length === 1,
  per_step_stable: predSigs.length === 1,
  conclusion: (verdicts.length > 1 || predSigs.length > 1)
    ? "CONFIRMED: the REAL array grader oscillates at serv-nano (primary). This is the cascade branch-point variance — root cause proven."
    : "Array grader STABLE here — variance must enter elsewhere (re-examine).",
  signatures: predSigs,
}, null, 2));
