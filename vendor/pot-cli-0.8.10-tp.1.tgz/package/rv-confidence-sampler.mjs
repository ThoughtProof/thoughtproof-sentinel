/**
 * rv-confidence-sampler.mjs — UNTRACKED local tool (do not commit).
 *
 * Samples the merged pot-cli RV pipeline (main @ f1aa3db, PR #49) against
 * real models to validate the 0.20/0.30 confidence-correction thresholds.
 *
 * Per run it records: judge confidences, judge mean, synthesizer STATED
 * confidence (pre-correction), final confidence, and which guardrail
 * actions fired. Clear-true claims are the primary class; a few contested
 * claims are included for contrast.
 *
 * Usage:
 *   node rv-confidence-sampler.mjs [--runs N] [--out results.jsonl]
 *
 * Keys (never echoed): SERV_API_KEY from openserv-sentinel/.env,
 * MOONSHOT_API_KEY from process env.
 */
import { readFileSync, appendFileSync, writeFileSync } from 'node:fs';
import { runReasoningVerification } from './dist/rv/index.js';

// ── env ─────────────────────────────────────────────────────────────
function parseEnv(path) {
  try {
    return Object.fromEntries(
      readFileSync(path, 'utf8').split('\n')
        .map(l => l.trim())
        .filter(l => l && !l.startsWith('#') && l.includes('='))
        .map(l => {
          const i = l.indexOf('=');
          return [l.slice(0, i).replace(/^export\s+/, '').trim(), l.slice(i + 1).trim().replace(/^["']|["']$/g, '')];
        })
    );
  } catch { return {}; }
}
const pool = { ...parseEnv('../openserv-sentinel/.env'), ...parseEnv('../verified-trading-agent/.env'), ...process.env };
const SERV_KEY = pool.SERV_API_KEY;
const MOONSHOT_KEY = pool.MOONSHOT_API_KEY;
if (!SERV_KEY) { console.error('SERV_API_KEY missing'); process.exit(1); }
if (!MOONSHOT_KEY) { console.error('MOONSHOT_API_KEY missing'); process.exit(1); }

// ── model callers ───────────────────────────────────────────────────
const SERV_URL = 'https://inference-api.openserv.ai/v1/chat/completions';
const MOONSHOT_URL = 'https://api.moonshot.ai/v1/chat/completions';
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function fetchWithTimeout(url, init, timeoutMs = 90_000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

async function callServ(model, messages, maxTokens) {
  const res = await fetchWithTimeout(SERV_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SERV_KEY}` },
    body: JSON.stringify({ model, messages, temperature: 0, max_completion_tokens: maxTokens }),
  });
  if (!res.ok) throw new Error(`SERV ${model} ${res.status}: ${(await res.text()).slice(0, 160)}`);
  const data = await res.json();
  const content = data.choices?.[0]?.message?.content ?? '';
  if (!String(content).trim()) throw new Error(`SERV ${model} empty content`);
  return { content, usage: { input: data.usage?.prompt_tokens ?? 0, output: data.usage?.completion_tokens ?? 0 } };
}

async function callMoonshot(messages, maxTokens) {
  // kimi-k2.6 is a reasoning model: reasoning_content consumes the token
  // budget. Measured: 2500 fully eaten (finish=length, empty content),
  // 4096 sufficient for judge stage. Scale ×5, floor 4096.
  const budget = Math.max(maxTokens * 5, 4096);
  const res = await fetchWithTimeout(MOONSHOT_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${MOONSHOT_KEY}` },
    body: JSON.stringify({ model: 'kimi-k2.6', messages, temperature: 1, max_tokens: budget }),
  }, 120_000);
  if (!res.ok) throw new Error(`Moonshot ${res.status}: ${(await res.text()).slice(0, 160)}`);
  const data = await res.json();
  // reasoning models may put text only in reasoning_content when budget is tight
  const msg = data.choices?.[0]?.message ?? {};
  const content = msg.content || msg.reasoning_content || '';
  if (!String(content).trim()) throw new Error(`Moonshot empty content finish=${data.choices?.[0]?.finish_reason}`);
  return { content, usage: { input: data.usage?.prompt_tokens ?? 0, output: data.usage?.completion_tokens ?? 0 } };
}

const caller = async ({ model, stage, messages, maxTokens }) => {
  const fn = model === 'kimi' ? () => callMoonshot(messages, maxTokens) : () => callServ(model, messages, maxTokens);
  let lastErr;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await fn();
      appendFileSync(DEBUG, JSON.stringify({ model, stage, attempt, len: r.content.length, head: r.content.slice(0, 400), tail: r.content.slice(-200) }) + '\n');
      return r;
    } catch (e) {
      lastErr = e;
      appendFileSync(DEBUG, JSON.stringify({ model, stage, attempt, error: String(e.message).slice(0, 200) }) + '\n');
      await sleep(1500 * (attempt + 1));
    }
  }
  throw lastErr;
};

// ── claims ──────────────────────────────────────────────────────────
// Clear-true: verifiable facts with solid evidence — the pre-fix collapse class.
const CLEAR_TRUE = [
  { id: 'ct-01', claim: 'Water boils at 100°C at standard atmospheric pressure (101.325 kPa).', rationale: 'Direct measurement under defined reference conditions; codified in the SI-aligned definition of the Celsius scale.', evidence: 'NIST Chemistry WebBook lists the normal boiling point of water at 373.15 K (99.97°C) at 1 atm; engineering references round to 100°C at 101.325 kPa.', domain: 'physics' },
  { id: 'ct-02', claim: 'The ERC-20 token standard defines a transfer(address,uint256) function that returns a boolean.', rationale: 'The function signature is part of the canonical interface published in the standard.', evidence: 'EIP-20 specification, Methods section: "function transfer(address _to, uint256 _value) public returns (bool success)".', domain: 'ethereum' },
  { id: 'ct-03', claim: 'The French Revolution began in 1789.', rationale: 'Conventionally dated from the Estates-General convening and the storming of the Bastille.', evidence: 'Encyclopaedia Britannica: "French Revolution, revolutionary movement that shook France between 1787 and 1799…" Bastille fell 14 July 1789.', domain: 'history' },
  { id: 'ct-04', claim: 'SHA-256 produces a 256-bit (32-byte) digest.', rationale: 'The digest length is fixed by the algorithm specification regardless of input size.', evidence: 'FIPS PUB 180-4, Secure Hash Standard: SHA-256 message digest is 256 bits.', domain: 'cryptography' },
  { id: 'ct-05', claim: 'Base is an Ethereum Layer-2 network incubated by Coinbase built on the OP Stack.', rationale: 'Publicly documented by both Coinbase and Optimism documentation.', evidence: 'docs.base.org: "Base is a secure, low-cost, builder-friendly Ethereum L2 built to bring the next billion users onchain… built on Optimism\'s open-source OP Stack."', domain: 'ethereum' },
  { id: 'ct-06', claim: 'The speed of light in vacuum is approximately 299,792,458 metres per second.', rationale: 'Exact defined value since the 1983 redefinition of the metre.', evidence: 'BIPM SI Brochure (9th edition): c = 299 792 458 m/s exactly, defining the metre.', domain: 'physics' },
  { id: 'ct-07', claim: 'Bitcoin\'s maximum supply is capped at 21 million coins by protocol consensus rules.', rationale: 'The issuance schedule halves the block subsidy every 210,000 blocks, asymptotically approaching 21M.', evidence: 'Bitcoin whitepaper §6 (incentive) + bitcoin source: consensus.nSubsidyHalvingInterval = 210000; total issuance converges to 20,999,999.9769 BTC.', domain: 'crypto' },
  { id: 'ct-08', claim: 'The Treaty of Westphalia was signed in 1648, ending the Thirty Years\' War.', rationale: 'Two peace treaties (Osnabrück and Münster) concluded the war in that year.', evidence: 'Britannica: "Peace of Westphalia, European settlements of 1648, which brought to an end the Eighty Years\' War… and the Thirty Years\' War."', domain: 'history' },
  { id: 'ct-09', claim: 'In JSON, the value types are string, number, object, array, boolean, and null.', rationale: 'The grammar in RFC 8259 defines exactly these six value productions.', evidence: 'RFC 8259 §3: "A JSON value MUST be an object, array, number, or string, or one of the following three literal names: false null true".', domain: 'software' },
  { id: 'ct-10', claim: 'Ethereum transitioned from proof-of-work to proof-of-stake in September 2022 ("The Merge").', rationale: 'The Merge activated at Terminal Total Difficulty on 15 September 2022.', evidence: 'ethereum.org: "The Merge was executed on September 15, 2022. This completed Ethereum\'s transition to proof-of-stake consensus."', domain: 'ethereum' },
  { id: 'ct-11', claim: 'A USDC token on Base uses 6 decimal places.', rationale: 'USDC implements the fiat-backed 6-decimal convention across chains, verifiable in the token contract.', evidence: 'Base mainnet USDC contract (0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913), decimals() returns 6; Circle documentation confirms 6 decimals.', domain: 'crypto' },
  { id: 'ct-12', claim: 'The Berlin Wall fell on 9 November 1989.', rationale: 'Border crossings opened the evening of 9 November 1989 after the Schabowski press conference.', evidence: 'Britannica and Bundesarchiv records: GDR border opened 9 November 1989.', domain: 'history' },
];

// Contested/false — contrast class, should NOT sit at high synth confidence.
const CONTESTED = [
  { id: 'cf-01', claim: 'The Great Wall of China is easily visible from the Moon with the naked eye.', rationale: 'It is very long, so it should be visible from far away.', evidence: 'Popular claim repeated in media; NASA astronaut statements conflict.', domain: 'space' },
  { id: 'cf-02', claim: 'Humans use only 10% of their brains.', rationale: 'Self-help literature has cited this figure for decades as untapped potential.', evidence: 'Common motivational claim; no controlled study cited.', domain: 'neuroscience' },
  { id: 'cf-03', claim: 'Bitcoin transactions are fully anonymous.', rationale: 'No names are attached to addresses, therefore transactions cannot be traced.', evidence: 'Addresses are pseudonymous strings; blockchain is public.', domain: 'crypto' },
  { id: 'cf-04', claim: 'Lightning never strikes the same place twice.', rationale: 'The charge in a location is discharged, so it cannot be struck again.', evidence: 'Empire State Building strike reports exist; mechanism unclear.', domain: 'physics' },
];

// ── runner ──────────────────────────────────────────────────────────
const args = process.argv.slice(2);
const argVal = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const OUT = argVal('--out', 'rv-confidence-sample.jsonl');
const DEBUG = argVal('--debug', 'rv-confidence-debug.jsonl');
const ONLY = argVal('--only', null); // e.g. --only clear

const PANEL = {
  judgeModels: ['serv-pro', 'serv-ultra', 'kimi'],
  // serv-swift (Haiku) as critic overflowed the pipeline's hardcoded 1000-token
  // critic budget (3878-char JSON truncated mid-array). serv-nano is the
  // pipeline default critic and writes compact JSON.
  criticModel: 'serv-nano',
  synthesizerModel: 'serv-standard',
};

async function runOne(c, klass) {
  const started = Date.now();
  const res = await runReasoningVerification({
    input: { id: c.id, claim: c.claim, rationale: c.rationale, evidence: c.evidence, domain: c.domain },
    caller,
    ...PANEL,
  });
  const judges = (res.critics ?? []).map(j => ({ model: j.model, verdict: j.verdict, confidence: j.confidence }));
  const confs = judges.map(j => j.confidence).filter(x => typeof x === 'number' && !isNaN(x));
  const judgeMean = confs.length ? +(confs.reduce((a, b) => a + b, 0) / confs.length).toFixed(3) : null;
  const stated = res.synthesis?.confidence ?? null;
  const gap = (stated != null && judgeMean != null) ? +(stated - judgeMean).toFixed(3) : null;
  const row = {
    id: c.id, class: klass, ts: new Date().toISOString(), ms: Date.now() - started,
    judges, judgeMean, synthStated: stated, gap,
    finalConfidence: res.confidence, finalVerdict: res.verdict,
    guardrail_actions: res.guardrail_actions ?? [],
  };
  appendFileSync(OUT, JSON.stringify(row) + '\n');
  console.log(`[${row.id}] verdict=${row.finalVerdict} stated=${row.synthStated} judgeMean=${row.judgeMean} gap=${row.gap} final=${row.finalConfidence} actions=[${row.guardrail_actions.join(',')}] (${(row.ms / 1000).toFixed(1)}s)`);
  return row;
}

function summarize(rows) {
  const byClass = k => rows.filter(r => r.class === k);
  const stats = rs => {
    const gaps = rs.map(r => r.gap).filter(g => g != null);
    const stated = rs.map(r => r.synthStated).filter(x => x != null);
    const means = rs.map(r => r.judgeMean).filter(x => x != null);
    const avg = a => a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(3) : null;
    return {
      n: rs.length,
      avgStated: avg(stated), avgJudgeMean: avg(means), avgGap: avg(gaps),
      gapAbove0_20: gaps.filter(g => g > 0.20).length,
      gapBelowMinus0_30: gaps.filter(g => g < -0.30).length,
      inflationOverrides: rs.filter(r => r.guardrail_actions.includes('judge_inflation_override')).length,
      deflationDampened: rs.filter(r => r.guardrail_actions.includes('judge_deflation_dampened')).length,
      correctionsTotal: rs.filter(r => r.guardrail_actions.some(a => a.startsWith('judge_'))).length,
    };
  };
  return { clear_true: stats(byClass('clear_true')), contested: stats(byClass('contested')), all: stats(rows) };
}

const main = async () => {
  // Resume: keep existing rows, skip IDs already sampled successfully.
  const doneIds = new Set();
  try {
    for (const line of readFileSync(OUT, 'utf8').split('\n')) {
      if (!line.trim()) continue;
      try { const d = JSON.parse(line); if (d.id && !d.error && d.finalVerdict) doneIds.add(d.id); } catch {}
    }
  } catch { writeFileSync(OUT, ''); }
  if (doneIds.size) console.log(`resuming — ${doneIds.size} claims already done: ${[...doneIds].join(', ')}`);
  const rows = [];
  const set = ONLY === 'clear' ? [[CLEAR_TRUE, 'clear_true']] : ONLY === 'contested' ? [[CONTESTED, 'contested']] : [[CLEAR_TRUE, 'clear_true'], [CONTESTED, 'contested']];
  const queue = [];
  for (const [claims, klass] of set) for (const c of claims) if (!doneIds.has(c.id)) queue.push([c, klass]);

  const runClaim = async ([c, klass]) => {
    for (let attempt = 0; attempt < 2; attempt++) {
      try { rows.push(await runOne(c, klass)); return; }
      catch (e) {
        if (attempt === 1) {
          console.error(`[${c.id}] FAILED after retry: ${e.message}`);
          appendFileSync(OUT, JSON.stringify({ id: c.id, class: klass, error: String(e.message).slice(0, 200) }) + '\n');
        } else {
          console.error(`[${c.id}] attempt 1 failed (${String(e.message).slice(0, 80)}), retrying…`);
          await sleep(2000);
        }
      }
    }
  };

  // Small worker pool — 2 concurrent claims keeps wall time ~half without
  // hammering provider rate limits.
  const CONCURRENCY = 3;
  const workers = Array.from({ length: CONCURRENCY }, async () => {
    while (queue.length) {
      const item = queue.shift();
      await runClaim(item);
      await sleep(500);
    }
  });
  await Promise.all(workers);
  // Summarize over the FULL file (resumed rows + new rows), not just this run.
  const allRows = [];
  for (const line of readFileSync(OUT, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try { const d = JSON.parse(line); if (d.id && !d.error && d.finalVerdict) allRows.push(d); } catch {}
  }
  const summary = summarize(allRows);
  console.log('\n=== SUMMARY ===');
  console.log(JSON.stringify(summary, null, 2));
  appendFileSync(OUT, JSON.stringify({ summary }) + '\n');
};

main().catch(e => { console.error(e); process.exit(1); });
